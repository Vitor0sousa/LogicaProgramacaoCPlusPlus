/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author 24153617
 */
public class Main {
    public static void main(String[] args) {
        Cachorro cachorro = new Cachorro("Snoop ",5,"O cachorro está latindo: Au Au!");
        cachorro.ExibirInformacoes();
        Passaro passaro = new Passaro("Calopsita",1,"O pássaro está cantando: Piu Piu!");
        passaro.ExibirInformacoes();
        Gato gato = new Gato(" Garfild",3," O gato está miando: Miau!");
        gato.ExibirInformacoes();
        
        
        
        
        
    }
    
    
    
    
    
    
    
}
