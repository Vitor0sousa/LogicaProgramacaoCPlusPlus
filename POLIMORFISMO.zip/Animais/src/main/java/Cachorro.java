/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author 24153617
 */
public class Cachorro extends Animal {

    public Cachorro(String nome, int idade, String acao) {
        super(nome, idade, acao);
    }
 @Override
public void ExibirInformacoes(){
     System.out.println("nome: "+nome+"idade:"+idade+acao);
}    
}
