/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author 24153617
 */
public class Animal {
    String nome;
    int idade;
    String acao;

    public Animal(String nome, int idade, String acao) {
        this.nome = nome;
        this.idade = idade;
        this.acao = acao;
    }
    
    public void ExibirInformacoes(){
        System.out.println("nome: "+nome+"idade:"+idade+acao);
        
    }
    
    
    
}
